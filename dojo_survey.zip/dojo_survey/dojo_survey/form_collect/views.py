from django.shortcuts import render,redirect

# Create your views here.
def show(request):
    return render(request, 'form.html')

def result(request):
    if request.method == "POST":
        val_name = request.POST["name"]
        val_location = request.POST.get("options")
        val_gender = request.POST.get("gender")
        val_language = request.POST.getlist("language")
        val_comment = request.POST["comment"]
        information={
            "example1" : "Submitted Info",
            "name" : val_name,
            "location" : val_location,
            "gender": val_gender,
            "language" : val_language,
            "comment": val_comment
        }
    return render(request, 'result.html', information)

def back(request):
    return redirect("/")
